from django.contrib import admin
from . models import *
# Register your models here.


admin.site.register(customer)
admin.site.register(mobilelist)
admin.site.register(brand)
admin.site.register(contac)
admin.site.register(feed)